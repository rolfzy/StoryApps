package com.example.storyapp


import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.storyapp.api.ApiConfig
import com.example.storyapp.api.ErrorResponse
import com.example.storyapp.api.ListStoryItem
import com.example.storyapp.data.UserModel
import com.google.gson.Gson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MainViewModel(private val storyRepository: StoryRepository) : ViewModel() {
    private val _stories = MutableStateFlow<List<ListStoryItem>>(emptyList())
    val Allstories = _stories

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading = _isLoading

    init {
        getStories()

    }

    fun getAllStories(token: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                val apiService = ApiConfig.getApiService()
                val succesResponse = apiService.getStories("Bearer $token")
                _stories.value = succesResponse.listStory

                Log.d(TAG, "MainViewModel sukses: ${succesResponse.message}")
            } catch (e: retrofit2.HttpException) {
                val errorBody = e.response()?.errorBody()?.string()
                val errorResponse = Gson().fromJson(errorBody, ErrorResponse::class.java)

                Log.d(TAG, "MainViewModel error: ${errorResponse.message}")
            }
            _isLoading.value = false
        }
    }


    fun getStories(): LiveData<UserModel> {
        return storyRepository.getStories().asLiveData()
    }

    fun logout() {
        viewModelScope.launch {
            storyRepository.logout()
        }
    }

    companion object {
        private const val TAG = "MainViewModel"
    }


}

