package com.example.storyapp.maps


import android.util.Log

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

import com.example.storyapp.StoryRepository
import com.example.storyapp.api.ListStoryItem
import com.example.storyapp.data.UserPreference
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MapsViewModel(
    private val storyRepository: StoryRepository,
    private val userPreference: UserPreference,
) : ViewModel() {

    private val _storyLocation = MutableLiveData<List<ListStoryItem>>()
    val storyLocation: LiveData<List<ListStoryItem>> get() = _storyLocation


    init {
        getStoryWithLocation()
    }

    private fun getStoryWithLocation() {
        viewModelScope.launch {
            try {
                val session = userPreference.getSession().first()
                val response = storyRepository.getStoriesWithLocation(session!!.token)
                Log.d("MapsViewModel", " Menerima session token: ${session?.token}")
                if (response.listStory.isNotEmpty()) {
                    _storyLocation.postValue(response.listStory)
                } else {
                    Log.d("MapsViewModel", "No stories found near user location")
                }
            } catch (e: Exception) {
                Log.e("MapsViewModel", "Error fetching stories: ${e.message}")
            }
        }
    }



}