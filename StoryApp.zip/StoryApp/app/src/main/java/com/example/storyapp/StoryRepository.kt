package com.example.storyapp



import com.example.storyapp.api.ApiConfig

import com.example.storyapp.api.StoryResponse
import com.example.storyapp.data.UserModel
import com.example.storyapp.data.UserPreference
import kotlinx.coroutines.flow.Flow


class StoryRepository private constructor(
    private val userPreference: UserPreference,

) {
    suspend fun saveStories(user:UserModel){
        userPreference.saveSession(user)
    }

    fun isLoggedIn():Flow<Boolean>{
        return userPreference.isLoggedIn()
    }

   fun getStories() : Flow<UserModel>{
        return userPreference.getSession()
    }

    suspend fun logout(){
        userPreference.logout()
    }
    suspend fun getStoriesWithLocation(token: String): StoryResponse {
        val ApiToken = ApiConfig.getApiService()
        return ApiToken.getStoriesWithLocation(1)
    }


    companion object {
        @Volatile
        private var instance: StoryRepository? = null

        fun getInstance(userPreference: UserPreference): StoryRepository =
            instance ?: synchronized(this) {
                instance ?: StoryRepository( userPreference ).also { instance = it }
            }
    }
}